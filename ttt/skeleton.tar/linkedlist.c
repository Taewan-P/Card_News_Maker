#include <stdio.h>
#include <stdlib.h>
#include "data_structure.h"

struct Node *at(struct Node *first, int index) {
	
}

struct Node *last(struct Node *first) {
	
}

int listSize(struct Node *first) {
	
}

int nodeInsert(struct Node *first, int data, int index) {
	
}

int nodeInsertEnd(struct Node *first, int data) {
	
}

int nodeRemove(struct Node *first, int index) {
	
}

int nodePrint(struct Node *first) {
	
}
