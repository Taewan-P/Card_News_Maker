#include <stdio.h>
#include <stdlib.h>
#include "data_structure.h"

int push(struct Foo *first, int data) {
	
}
int pop(struct Foo *first) {
	
}

int stackSize(struct Foo *first) {

}