#include <stdio.h>
#include <stdlib.h>
#include "data_structure.h"

int main(int argc, char const *argv[]) {
	struct Node *first = (struct Node *) malloc(sizeof(struct Node));
	struct Foo *stack = (struct Foo *) malloc(sizeof(struct Foo));

	first->data = 9;
	first->prev = NULL;
	first->next = NULL;
	nodeInsertEnd(first, 4);
	printf("Insert done\n");
	nodeInsertEnd(first, 1);
	printf("Insert done\n");
	nodeInsertEnd(first, 2);
	printf("Insert done\n");
	nodeInsertEnd(first, 8);
	printf("Insert done\n");
	nodePrint(first);
	nodeInsert(first, 7, 2);
	printf("Insert done\n");
	nodePrint(first);
	nodeRemove(first, 1);
	printf("Remove done\n");
	nodePrint(first);
	printf("Data at pos 2: %d\n", at(first, 2)->data);
	printf("Data at last node: %d\n", last(first)->data);

	stack->first = NULL;
	push(stack, 4);
	printf("Push done\n");
	push(stack, 1);
	printf("Push done\n");
	push(stack, 2);
	printf("Push done\n");
	push(stack, 8);
	printf("Push done\n");
	pop(stack);
	printf("Pop done\n");
	pop(stack);
	printf("Pop done\n");
	
	nodePrint(stack->first);	
	return 0;
}