struct Node {
	struct Node *prev;
	struct Node *next;
	int data;
};

struct Foo {
	struct Node *first;
};

struct Node *at(struct Node *first, int index);
struct Node *last(struct Node *first);
int listSize(struct Node *first);
int nodeInsert(struct Node *first, int data, int index);
int nodeRemove(struct Node *first, int index);
int nodeInsertEnd(struct Node *first, int data);
int nodePrint(struct Node *first);

int push(struct Foo *stack, int data);
int pop(struct Foo *stack);
int stackSize(struct Foo *stack);